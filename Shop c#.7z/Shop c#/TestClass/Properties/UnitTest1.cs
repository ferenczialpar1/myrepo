﻿using System;
using System.Collections.Generic;
using Microsoft.Build.Tasks.Deployment.Bootstrapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestClass.Properties
{
    [TestClass]
    public class UnitTest1
    {
        private List<Product> shopinverntorytest = new List<Product>();

        private Discounts 

        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}

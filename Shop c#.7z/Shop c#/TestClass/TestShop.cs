﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestClass
{
    [TestClass]
    public class TestShop
    {
       private List<Product> shopinverntorytest = new List<Product>();

       private Shop.RegisterProduct("A", 10.0);
       private Shop.RegisterProduct("B", 100.0);
       private Shop.RegisterProduct("C", 20.0);

        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}

﻿using Microsoft.Build.Tasks.Deployment.Bootstrapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace TestClass
{
    [Fact]

    class Class1
    {
        private List<Product> shopinverntorytest = new List<Product>();

        private Discounts

        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
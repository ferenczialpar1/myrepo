﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hf_shop_F49E0D
{
    public class Shop
    {

        private List<Product> shopinverntory = new List<Product>();
        private List<ComboDiscounts> shopcombodiscountinverntory = new List<ComboDiscounts>();
        private List<CountDiscounts> shopcountdiscountinverntory = new List<CountDiscounts>();
        private List<AmountDiscounts> shopamountdiscountinverntory = new List<AmountDiscounts>();
        private List<ComboDiscounts> shopcoupondiscountinverntory = new List<ComboDiscounts>();
        private readonly List<ClientsDatabase> clients = new List<ClientsDatabase>();

        public Shop()
        {
            shopinverntory = new List<Product>();
            shopcountdiscountinverntory = new List<CountDiscounts>();
            shopamountdiscountinverntory = new List<AmountDiscounts>();
            shopcombodiscountinverntory = new List<ComboDiscounts>();
            shopcoupondiscountinverntory = new List<ComboDiscounts>();
    }
        public void RegisterProduct(string newproductname, double newproductprice)
        {
            bool contains = false;
            Product s = new Product(newproductname, newproductprice);
            for (int i = 0; i < shopinverntory.Count; i++)
            {
                if (shopinverntory[i].getName().Equals(newproductname) && shopinverntory[i].getPrice() >= newproductprice)
                {
                    shopinverntory[i].setPrice(newproductprice);
                    contains = true;
                }
                else if (shopinverntory[i].getName().Equals(newproductname) && shopinverntory[i].getPrice() < newproductprice)
                {
                    contains = true;
                    break;
                }
            }
            if (contains is false)
            {
                shopinverntory.Add(s);
            }
        }
        public double GetPrice(string x)
        {
            double sum = 0;

            for (int i = 0; i < x.Length; i++)
            {
                for (int j = 0; j < shopinverntory.Count; j++)
                {
                    if (string.Compare(x[i].ToString(), shopinverntory[j].getName()) == 0)
                    {
                        sum += shopinverntory[j].getPrice();
                    }
                }
            }
            sum+=CompareDiscounts(x, sum);

            if (x.Any(c => char.IsDigit(c)))
            {
                sum = UserIdDiscount(x,sum);
                sum *= 0.9;
                
            }

            else if (ContainsDiscount(x, "t").Equals(true))
            {
                return sum * 0.9;
            }

            return sum;
        }
        public void RegisterComboDiscount(string name, double payedwithpercentage)
        {
            ComboDiscounts s = new ComboDiscounts(name, payedwithpercentage);
            shopcoupondiscountinverntory.Add(s);
        }
        public void RegisterCountDiscount(string name,int payed,int payedwithplus)
        {
            CountDiscounts s = new CountDiscounts(name, payed, payedwithplus);
            shopcountdiscountinverntory.Add(s);
        }
        public void RegisterAmountDiscount(string name, int payed, double payedwithpercentage)
        {
            AmountDiscounts s = new AmountDiscounts(name, payed, payedwithpercentage);
            shopamountdiscountinverntory.Add(s);
        }
        public void RegisterComboDiscount(string name, int payed)
        {
            ComboDiscounts s = new ComboDiscounts(name, payed);
            shopcombodiscountinverntory.Add(s);
        }
        public bool WhatIsNextElement(string x,int n1)
        {
            if((n1 + 1) < x.Length && !x[n1].Equals(x[n1 + 1]))
            {
                return true;
            }
            else if ((n1 + 1) >= x.Length)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool ContainsDiscount(string elements,string substring)
        {
            List<Char> elementlist = new List<Char>();
            int checklength = 0;
            for (int i = 0; i < substring.Length; i++)
            {
                for (int j = 0; j < elements.Length; j++)
                {
                    if(substring[i].Equals(elements[j]))
                    {
                        elements = ReplaceAtIndex(elements.IndexOf(substring[i]), elements);

                        elementlist.Add(substring[i]);
                        checklength++;
                        break;
                    }
                }
            }
            if (checklength.Equals(substring.Length) || elementlist.Distinct().ToList().Count.Equals(substring.Length))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public string ReplaceAtIndex(int index, string substring)
        {
            var theString = substring;
            var aStringBuilder = new StringBuilder(theString);
            aStringBuilder.Remove(index, 1);
            aStringBuilder.Insert(index, "X");
            return aStringBuilder.ToString();
        }
        public string ComboDiscountMethod(string discountname,string x)
        {
            for (int l = 0; l < discountname.Length; l++)
            {
                for (int m = 0; m < shopinverntory.Count; m++)
                {
                    var s = discountname[l];
                    if (s.ToString().Equals(shopinverntory[m].getName())&& x.IndexOf(shopinverntory[m].getName()) >= 0)
                    {
                        x = ReplaceAtIndex(x.IndexOf(shopinverntory[m].getName()), x);
                    }
                }
            }
            return x;
        }
        public int CheckClubcardBalance(int s,double sum)
        {
            for(int l = 0; l < clients.Count; l++)
                {
                if(clients[l].getName().Equals(s))
                {
                    int discountvalue = Convert.ToInt32(clients[l].getPrice());
                    clients[l].setPrice(sum*0.01);
                    return discountvalue;
                }
            }
            return 0;
        }
        public void addClubcardBalance(int s,double sum)
        {
            for (int l = 0; l < clients.Count; l++)
            {
                if (clients[l].getName().Equals(s))
                {
                    double supershoppoint= sum * 0.01;
                    clients[l].addBalance(supershoppoint);
                }
            }
            ClientsDatabase newperson = new ClientsDatabase(s, sum * 0.01);
            if (!clients.Contains(newperson))
            {
                clients.Add(newperson);
            }
        }
        public int countDiscount(string x)
        {
            double discountvalue = 0;
            for (int j = 0; j < shopcountdiscountinverntory.Count; j++)
            {
                string discountexactname = string.Concat(Enumerable.Repeat(shopcountdiscountinverntory[j].getName(), Convert.ToInt32(shopcountdiscountinverntory[j].getForgratis())));
                if (ContainsDiscount(x,discountexactname) is true)
                {
                    for (int k= 0; k< shopinverntory.Count; k++)
                    {
                        if (shopcountdiscountinverntory[j].getName().Equals(shopinverntory[k].getName()))
                        {
                            discountvalue -= shopinverntory[k].getPrice()*(shopcountdiscountinverntory[j].getForgratis() - shopcountdiscountinverntory[j].getPieces());
                            break;
                        }
                    }
                }
            }
            Console.WriteLine("Darabkedvezmény");
            return Convert.ToInt32(discountvalue);
        }
        public int amountDiscount(string x)
        {
            double discountvalue = 0;
            for (int j = 0; j < shopamountdiscountinverntory.Count; j++)
            {
                string discountexactname = string.Concat(Enumerable.Repeat(shopamountdiscountinverntory[j].getName(), Convert.ToInt32(shopamountdiscountinverntory[j].getGratispercentage())));
                if (ContainsDiscount(x, discountexactname) is true)
                {
                    for (int k = 0; k < shopinverntory.Count; k++)
                    {
                        if (shopamountdiscountinverntory[j].getName().Equals(shopinverntory[k].getName()))
                        {
                            discountvalue-= (shopinverntory[k].getPrice()* shopamountdiscountinverntory[j].getPieces()) * (1- shopamountdiscountinverntory[j].getGratispercentage());
                            break;
                        }
                    }
                }
            }
            Console.WriteLine("Mennyiségikedvezmény");
            return Convert.ToInt32(discountvalue);
        }
        public int comboDiscount(string p)
        {
            string x = p;
            double discountsum = 0;
            double discountvalue = 0;
            for (int j = 0; j < shopcombodiscountinverntory.Count; j++)
            {
                if (ContainsDiscount(x, shopcombodiscountinverntory[j].getName()) is true)
                {
                    for (int k = 0; k < shopinverntory.Count; k++)
                    {
                        if(shopcombodiscountinverntory[j].getName().Contains(shopinverntory[k].getName()))
                        {
                            discountsum += shopinverntory[k].getPrice();
                            x=ReplaceAtIndex(x.IndexOf(shopinverntory[k].getName()), x);
                        }
                    }
                    discountvalue-= (discountsum - shopcombodiscountinverntory[j].getComboPrice());
                    discountsum = 0;
                }
            }
            Console.WriteLine("ComboKedvezmény");
            return Convert.ToInt32(discountvalue);
        }
        public double UserIdDiscount(string x,double sum)
        {
            string idnumber = new String(x.Where(Char.IsDigit).ToArray());
            int buyerId = Int32.Parse(idnumber);

            if (ContainsDiscount(x, "p").Equals(true))
            {
                sum -=CheckClubcardBalance(buyerId,sum);
                if(CheckClubcardBalance(buyerId, sum).Equals(0))
                {
                addClubcardBalance(buyerId, sum);
                }
            }
            else
            {
                addClubcardBalance(buyerId, sum);
            }
            return sum;
        }
        public int CompareDiscounts(string x, double sum)
        {
            int alldiscount = 0;
            alldiscount+=(countDiscount(x));
            alldiscount += (amountDiscount(x));
            alldiscount += (comboDiscount(x));
            //alldiscount += (couponDiscount(x, sum));
            return alldiscount;
        }
        public int couponDiscount(string x, double sum)
        {
            return 10;
            /*string idnumber = new String(x.Where(Char.IsDigit).ToArray());
            int buyerId = Int32.Parse(idnumber);
            if (ContainsDiscount(x, "k").Equals(true))
            {
                string s = getCoupon(x);
                for (int k = 0; k < x.Length; k++)
                {
                    for (int j = 0; j < s.Length; j++)
                    {
                        if (s[j].Equals(x[j]))
                        {
                            x = ReplaceAtIndex(j, x);
                        }
                    }
                }
                string idnumber2 = new String(x.Where(Char.IsDigit).ToArray());
                //int buyerId = Int32.Parse(idnumber2);
                return 10;

            }
            return 10;
            /*if(ContainsDiscount(x, "k").Equals(false))
            {
                string s = getCoupon(x);
            for (int k = 0; k < x.Length; k++)
                {
                    for (int j = 0; j < s.Length; j++)
                    {
                        if(s[j].Equals(x[j]))
                        {
                            x = ReplaceAtIndex(j, x);
                        }
                    }
                }
                string idnumber = new String(x.Where(Char.IsDigit).ToArray());
                int buyerId = Int32.Parse(idnumber);
                sum -= CheckClubcardBalance(buyerId, sum);
                if (CheckClubcardBalance(buyerId, sum).Equals(0))
                {
                    addClubcardBalance(buyerId, sum);
                }
                return (-1)*sum;

            }
            else if (ContainsDiscount(x, "k").Equals(true))
            {
                string idnumber = new String(x.Where(Char.IsDigit).ToArray());
                int buyerId = Int32.Parse(idnumber);
                sum -= CheckClubcardBalance(buyerId, sum);
                if (CheckClubcardBalance(buyerId, sum).Equals(0))
                {
                    addClubcardBalance(buyerId, sum);
                }
                return (-1) * sum;
            }
            else
            {
                return (-1) * sum;
            }*/

        }
        public string getCoupon(string x)
        {
            var numbers = new List<int>();
            string[] words = x.Split('k');
            for (int j = 0; j < words[2].Length; j++)
            {
                if (!(words[2][j] >= '0' && words[2][j] <= '9'))
                {
                    break;
                }
                else if (words[2][j] >= '0' && words[2][j] <= '9')
                {
                    numbers.Add((int)Char.GetNumericValue(words[2][j]));
                }
            }
            return string.Join(",", numbers);
        }
    }
}



 


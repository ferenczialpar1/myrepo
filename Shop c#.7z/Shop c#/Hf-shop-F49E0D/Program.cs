﻿using System;
using System.Collections.Generic;

namespace Hf_shop_F49E0D
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Vegyesbolt");

            /////////////////////1.feladat
            //Shop.RegisterProduct("A", 10.0);
            //Shop.RegisterProduct("B", 100.0);
            //Shop.RegisterProduct("C", 20.0);
            //Shop.RegisterProduct("t", 0.0);
            //var price = Shop.GetPrice();
            //Console.WriteLine("Teljes ár "+ price);
            //var price2 = Shop.GetPrice("ABCCACB");
            //Console.WriteLine("Teljes ár " + price2);

            ///////////////////2.feladat
            //Console.WriteLine("__________");
            //Shop.RegisterCountDiscount("A",5.0,4.0);
            //var price3 = Shop.GetPrice("AAAAAAAAAA");

            //Console.WriteLine("Teljes ár " + price3);


            ///////////////////3.feladat
            Console.WriteLine("__________");
            //Shop.RegisterAmountDiscount("A", 3.0, 0.9);
            //3 áráért 4-et vihet
            //Shop.RegisterCountDiscount("A", 3.0, 4.0);

            ///////////////////5.feladat
            //var price2 = Shop.GetPrice("AAAABAAAA");
            //Console.WriteLine("Teljes ár " + price2);
            //Shop.RegisterProduct("A", 10.0);
            //Shop.RegisterProduct("B", 20.0);
            //Shop.RegisterProduct("C", 50.0);
            //Shop.RegisterProduct("D", 50.0);
            //Shop.RegisterComboDiscount("ABC", 60.0);
            //Shop.RegisterComboDiscount("AD", 50.0);
            //var price = Shop.GetPrice("AABDCAD");
            //Console.WriteLine("Teljes ár " + price);
            ///////////////////6.feladat
            //var price2 = Shop.GetPrice("AAAABAAAA");
            //Console.WriteLine("Teljes ár " + price2);
            /*new Shop();
            Shop.RegisterProduct("A", 10.0);
            Shop.RegisterProduct("B", 20.0);
            Shop.RegisterProduct("C", 50.0);
            Shop.RegisterProduct("D", 50.0);
            Shop.RegisterComboDiscount("ABC", 60);
            Shop.RegisterComboDiscount("AD", 50);

            Console.WriteLine(Shop.comboDiscount("AABDCAD"));
            Console.WriteLine(Shop.ContainsDiscount("XAXDXAD", "AD"));
           // Console.WriteLine(Convert.ToInt32(new string(x[i], 1)););
        }
    }*/
        }
    }
}



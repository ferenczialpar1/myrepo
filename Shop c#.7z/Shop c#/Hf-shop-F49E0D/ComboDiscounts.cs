﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hf_shop_F49E0D
{
    class ComboDiscounts:Discounts
    {
        private string name;
        private double comboPrice;


        public ComboDiscounts(string nabe, double xparam) : base(nabe)
        {
            name = nabe;
            comboPrice = xparam;
        }

        public double getComboPrice()
        {
            return comboPrice;
        }
        public void setComboPrice(double xparam)
        {
            comboPrice = xparam;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hf_shop_F49E0D
{
    public class Product
    {
        private string name;
        private double price;
        public Product(string productName, double productPrice)
        {
            name = productName;
            price = productPrice;
        }
        public string getName()
        {
            return name;
        }
        public double getPrice()
        {
            return price;
        }
        public void setName(string productName)
        {
            name = productName;
        }
        public void setPrice(double productPrice)
        {
            price = productPrice;
        }
    }
}

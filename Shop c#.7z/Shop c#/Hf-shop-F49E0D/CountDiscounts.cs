﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hf_shop_F49E0D
{
    class CountDiscounts:Discounts
    {
        private string name;
        private int pieces;
        private int forgratis;

        public CountDiscounts(string nabe, int xparam, int yparam) : base(nabe)
        {
            name = nabe;
            pieces = xparam;
            forgratis = yparam;
        }

        public int getForgratis()
        {
            return forgratis;
        }
        public void setForgratis(int xparam)
        {
            forgratis = xparam;
        }
        public void setPieces(int xparam)
        {
            pieces = xparam;
        }
        public double getPieces()
        {
            return pieces;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hf_shop_F49E0D
{
    class DiscountAmount:Discounts
    {
        int x;
        double y;

        public double getx()
        {
            return x;
        }
        public void setx(int xparam)
        {
            x = xparam;
        }
        public double gety() => y;
        public void sety(double yparam)
        {
            y = yparam;
        }
    }
}

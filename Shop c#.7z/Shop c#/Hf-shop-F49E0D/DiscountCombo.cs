﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hf_shop_F49E0D
{
    class DiscountCombo:Discounts
    {
        int x;

        public double getx()
        {
            return x;
        }
        public void setx(int xparam)
        {
            x = xparam;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hf_shop_F49E0D
{
    class DiscountsCount:Discounts
    {
        int x;
        int y;

        public double getx()
        {
            return x;
        }
        public void setx(int xparam)
        {
            x = xparam;
        }
        public int gety() => y;
        public void sety(int yparam)
        {
            y = yparam;
        }
    }
}

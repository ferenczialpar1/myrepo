﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hf_shop_F49E0D
{
    public class AmountDiscounts : Discounts
    {
        private string name;
        private int pieces;
        private double gratispercentage;

        public AmountDiscounts(string nabe,int xparam, double yparam) :base(nabe)
        {
            name = nabe;
            pieces = xparam;
            gratispercentage = yparam;
        }

        public double getGratispercentage()
        {
            return gratispercentage;
        }
        public void setGratispercentage(double xparam)
        {
            gratispercentage = xparam;
        }
        public void setPieces(int xparam)
        {
            pieces = xparam;
        }
        public double getPieces()
        {
            return pieces;
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hf_shop_F49E0D
{
    public class Discounts
    {
        private string name;

        public Discounts(string productName)
        {
            name = productName;
        }
        public string getName()
        {
            return name;
        }
        
        public void setName(string productName)
        {
            name = productName;
        }
    }
}

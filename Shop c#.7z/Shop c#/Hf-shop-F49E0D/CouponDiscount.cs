﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hf_shop_F49E0D
{
    class CouponDiscount : Discounts
        {
        private string name;
        private double comboPrice;

        public CouponDiscount(string nabe, double xparam) : base(nabe)
        {
            name = nabe;
            comboPrice = xparam;
        }

        public double getCouponPrice()
        {
            return comboPrice;
        }
        public void setCouponPrice(double xparam)
        {
            comboPrice = xparam;
        }
        public void setPieces(double xparam)
        {
            comboPrice = xparam;
        }
        public double getPieces()
        {
            return comboPrice;
        }
    }
}


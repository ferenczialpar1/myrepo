﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hf_shop_F49E0D
{
    class ClientsDatabase
    {
        private int clientId;
        private double balance;
        public ClientsDatabase(int clientIdnumbr,double balanceadd)
        {
            clientId = clientIdnumbr;
            balance = balanceadd;
        }
        public int getName()
        {
            return clientId;
        }
        public double getPrice()
        {
            return balance;
        }
        public void setName(int clientIdnumbr)
        {
            clientId = clientIdnumbr;
        }
        public void setPrice(double productsSumPrice)
        {
            balance = productsSumPrice;
        }
        public void addBalance(double productsSumPrice)
        {
            balance += productsSumPrice;
        }
        public void toString()
        {
            Console.WriteLine("clientId:"+ clientId, "balance"+ balance);
        }
    }
}

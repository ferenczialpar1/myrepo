﻿using System;
using System.Collections.Generic;
using Hf_shop_F49E0D;
using Microsoft.Build.Tasks.Deployment.Bootstrapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Hf_Shop_test
{
    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public void Első_feladat_Regisztrálás_Árszámítás()
        {
            Shop s = new Shop();
            s.RegisterProduct("A", 10.0);
            s.RegisterProduct("C", 20.0);
            s.RegisterProduct("E", 50.0);
            Assert.AreEqual(100.0,s.GetPrice("ACCE"));
            Assert.AreEqual(10.0, s.GetPrice("A"));
            Assert.AreEqual(20.0, s.GetPrice("C"));
            Assert.AreEqual(130.0, s.GetPrice("ACEE"));
        }
        [TestMethod]
        public void Második_feladat_N_áron_M_db()
        {
            Shop s = new Shop();
            s.RegisterProduct("A", 10.0);
            s.RegisterProduct("B", 20.0);
            s.RegisterProduct("C", 50.0);
            s.RegisterProduct("D", 50.0);
            s.RegisterCountDiscount("A", 3, 4);
            s.RegisterCountDiscount("C", 2, 3);
            Assert.AreEqual(140, s.GetPrice("AAAAACCC"));
            Assert.AreEqual(-60.0, s.countDiscount("AAAAACCC"));
        }
        [TestMethod]
        public void Harmadik_feladat_Mennyiségikedvezmény()
        {
            Shop s = new Shop();
            s.RegisterProduct("A", 10.0);
            s.RegisterProduct("B", 20.0);
            s.RegisterProduct("C", 50.0);
            s.RegisterProduct("D", 50.0);
            s.RegisterAmountDiscount("A", 5, 0.9);
            Assert.AreEqual(65.0, s.GetPrice("AAAAAB"));
            Assert.AreEqual(-5,s.amountDiscount("AAAAAAB"));
        }
        [TestMethod]
        public void Negyedik_feladat()
        {
            Shop s = new Shop();
            s.RegisterProduct("A", 10.0);
            s.RegisterProduct("B", 20.0);
            s.RegisterProduct("C", 50.0);
            s.RegisterProduct("D", 50.0);
            s.RegisterComboDiscount("ABC", 60);
            s.RegisterComboDiscount("AD", 50);
            Assert.AreEqual(170.0,s.GetPrice("AABDCAD"));//(AAABCDD)
            Assert.AreEqual(110.0, s.GetPrice("CAAAABB"));
            //Kapcsolódó metódusok 
            Assert.AreEqual(-30, s.comboDiscount("AABDCAD"));
            Assert.AreEqual(-20, s.comboDiscount("CAAAABB"));


        }
        [TestMethod]
        public void Ötödik_feladat()
        {
            Shop s = new Shop();
            s.RegisterProduct("A", 10.0);
            s.RegisterProduct("B", 20.0);
            s.RegisterProduct("C", 50.0);
            Assert.AreEqual(90.0, s.GetPrice("tABBC"));
            Assert.AreEqual(9.0, s.GetPrice("tA"));

            //Kapcsolódó metódusok
            Assert.IsTrue(s.ContainsDiscount("AABDtCAD", "t"));
        }
        [TestMethod]
        public void Hatodik_feladat()
        {
            Shop s = new Shop();
            s.RegisterProduct("A", 10.0);
            s.RegisterProduct("B", 20.0);
            s.RegisterProduct("C", 50.0);
            s.RegisterComboDiscount("ABCt", 40);
            Assert.AreEqual(36, s.GetPrice("tABC"));
            Assert.AreEqual(80, s.GetPrice("ABC"));
            
            //Kapcsolódó metódusok
            Assert.IsTrue(s.ContainsDiscount("AABDCAD", "ABCD"));
            Assert.AreEqual("XXXD",s.ComboDiscountMethod("ABC", "ABCD"));
            Assert.AreEqual("SXOP", s.ReplaceAtIndex(1, "SHOP"));

        }
        /*[TestMethod]
        public void Hetedik_feladat()
        {
            Shop s = new Shop();
            s.RegisterProduct("A", 10.0);
            s.RegisterProduct("B", 20.0);
            s.RegisterProduct("C", 100.0);
            Assert.AreEqual(500.0, s.GetPrice("3CCCCC"));
            Assert.AreEqual(395.0, s.GetPrice("3CCCCp"));
            Assert.AreEqual(196.0, s.GetPrice("3CCp"));
            Assert.AreEqual(400.0, s.GetPrice("4CCCCp"));
            Assert.AreEqual(396.0, s.GetPrice("4CCCCp"));
            Assert.AreEqual(98.0, s.GetPrice("3Cp"));

            //Kapcsolódó metódusok
            Assert.AreEqual(1, s.CheckClubcardBalance(3, 100));
            s.addClubcardBalance(3, 500);
            Assert.AreEqual(6, s.CheckClubcardBalance(3, 100));
            Shop r = new Shop();
            r.RegisterProduct("A", 10.0);
            r.RegisterProduct("B", 20.0);
            r.RegisterProduct("C", 100.0);
            Assert.AreEqual(500.0, r.GetPrice("19CCCCC"));
            Assert.AreEqual(395.0, r.GetPrice("19CCCCp"));
        }*/
        [TestMethod]
        public void Laborrakértfeladat()
        {
            Shop s = new Shop();
            s.RegisterProduct("A", 20.0);
            s.RegisterProduct("A", 10.0);
            Assert.AreEqual(10, s.GetPrice("A"));
            //Shop.RegisterProduct("A", 20.0);

        }

        [TestMethod]
        public void MásodikElsőTöbbkedvezmény()
        {
            Shop r = new Shop();
            r.RegisterProduct("A", 10.0);
            r.RegisterProduct("B", 20.0);
            r.RegisterProduct("C", 50.0);
            r.RegisterProduct("D", 100.0);
            r.RegisterComboDiscount("ABC", 60);
            r.RegisterComboDiscount("AD", 50);
            r.RegisterCountDiscount("A", 3, 4);
            r.RegisterCountDiscount("C", 2, 3);
            r.RegisterAmountDiscount("A", 5, 0.9);
            Assert.AreEqual(175, r.GetPrice("AAAAABDCCC"));
        }
        [TestMethod]
        public void MásodikMásodikIDtenpercent()
        {
            Shop r = new Shop();
            r.RegisterProduct("A", 10.0);
            r.RegisterProduct("B", 20.0);
            r.RegisterProduct("C", 100.0);
            Assert.AreEqual(450.0, r.GetPrice("19CCCCC"));
            Assert.AreEqual(355.5, r.GetPrice("19CCCCp")); //-10% 40 -1% előző vásárlás 4,5
            Assert.AreEqual(900, r.GetPrice("1966CCCCCCCCCC"));
            Assert.AreEqual(351.0, r.GetPrice("CC1966CCp"));
        }
        [TestMethod]
        public void MásodikHarmadikHosszúID()
        {
            Shop r = new Shop();
            r.RegisterProduct("A", 10.0);
            r.RegisterProduct("B", 20.0);
            r.RegisterProduct("C", 100.0);
            Assert.AreEqual(450.0, r.GetPrice("19CCCCC"));
            Assert.AreEqual(355.5, r.GetPrice("19CCCCp")); //-10% 40 -1% előző vásárlás 4,5
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarFactory
{
    class ConcreteProductA2 : IAbstractProductA
    {
        public string GetModelDetails()
        {
            return "The result of the product A2.";
        }
    }
}

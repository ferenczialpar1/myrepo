﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarFactory
{
    class Client
    {
        public void Main()
        {
            // The client code can work with any concrete factory class.
            Console.WriteLine("Client: Testing client code with the first factory type...");
            ClientMethod(new ConcreteFactory1());
            Console.WriteLine();
        }

        public void ClientMethod(IAbstractFactory factory)
        {
            int s = 10;
            var productA = factory.ManufactureVeichle(s);

            Console.WriteLine(productA.GetModelDetails());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarFactory
{
    class ConcreteFactory1 : IAbstractFactory
    {
        public IAbstractProductA ManufactureVeichle(int s)
        {
            return new ConcreteProductA1();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarFactory
{
    public interface IAbstractFactory
    {
        IAbstractProductA ManufactureVeichle(int s);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarFactory
{
    class Car
    {
        bool frame;
        bool engine;
        bool body;

        public Car(bool frame, bool engine,bool body)
        {
            this.frame = frame;
            this.engine = engine;
            this.body = body;
        }

}
}

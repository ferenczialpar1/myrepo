﻿using System;

namespace CarFactory
{
    class Program
    {
        static void Main(string[] args)
        {
            new Client().Main();
        }
    }
}

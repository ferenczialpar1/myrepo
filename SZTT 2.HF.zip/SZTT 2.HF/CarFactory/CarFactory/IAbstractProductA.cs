﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarFactory
{
    public interface IAbstractProductA
    {
        string GetModelDetails();
    }
    /*public override Car GetModelDetails()
        {
            Car s = new Car(true, true, true);
            return s;
        }*/
}

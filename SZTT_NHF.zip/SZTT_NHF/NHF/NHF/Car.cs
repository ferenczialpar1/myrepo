﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    public class Car
    {
        Frame carFrame;
        Body carBody;
        Engine carEngine;

        public Car(Frame carFrame, Body carBody, Engine carEngine)
        {
            this.carFrame = carFrame;
            this.carBody = carBody;
            this.carEngine = carEngine;
        }
        /*
        public Frame CarFrame { get => carFrame; set => carFrame = value; }
        public Body CarBody { get => carBody; set => carBody = value; }
        public Engine CarEngine { get => carEngine; set => carEngine = value; }
        */
    }
}

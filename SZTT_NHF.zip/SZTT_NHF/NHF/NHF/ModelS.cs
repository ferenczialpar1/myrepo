﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    public class ModelSFrame : Frame
    {
        public override void AssemblyFrame()
        {
            throw new NotImplementedException();
        }
    }

    public class ModelSBody : Body

    {
        public override void AssemblyBody()
        {
            throw new NotImplementedException();
        }
    }



    // A Scrollbar OXS témájú implementációja

    public class ModelSEngine : Engine
    {
        public override void AssemblyEngine()
        {
            throw new NotImplementedException();
        }
    }
}

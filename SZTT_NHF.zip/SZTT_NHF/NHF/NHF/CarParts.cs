﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    public abstract class Frame
    {
        public abstract void AssemblyFrame();
        public void Show() { }
    }

    public abstract class Body
    {
        public abstract void AssemblyBody();
    }

    public abstract class Engine
    {
        public abstract void AssemblyEngine();
    }
}

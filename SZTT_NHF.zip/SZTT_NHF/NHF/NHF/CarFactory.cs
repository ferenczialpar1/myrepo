﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    namespace NHF
    {
        interface CarFactory
        {
            Frame CreateFrame();
            Body CreateBody();
            Engine CreateEngine();
            public void makeCars(int n)
            {
                for(int i=0; i<n; i++)
                {
                    Car newcar = assembleCars(CreateFrame(), CreateBody(), CreateEngine());
                    Console.WriteLine(this.GetType().Name + "Made a new car");
                }
            }
            public Car assembleCars(Frame carframe, Body carbody, Engine carengine)
            {
                Car newcar = new Car(carframe, carbody, carengine);
                return newcar;
            }
        }
        class TeslaModelSFactory : CarFactory
        {
            public Frame CreateFrame() { return new ModelSFrame(); }
            public Body CreateBody() { return new ModelSBody(); }
            public Engine CreateEngine() { return new ModelSEngine(); }

        }
        class TeslaModelYFactory : CarFactory
        {
            public Frame CreateFrame() { return new ModelYFrame(); }
            public Body CreateBody() { return new ModelYBody(); }
            public Engine CreateEngine() { return new ModelYEngine(); }

        }
    }
}

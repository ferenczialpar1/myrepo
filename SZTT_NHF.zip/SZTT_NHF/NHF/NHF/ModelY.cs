﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    public class ModelYFrame : Frame
    {
        public override void AssemblyFrame()
        {
            throw new NotImplementedException();
        }
    }

    public class ModelYBody : Body

    {
        public override void AssemblyBody()
        {
            throw new NotImplementedException();
        }
    }

    public class ModelYEngine : Engine

    {
        public override void AssemblyEngine()
        {
            throw new NotImplementedException();
        }
    }
}

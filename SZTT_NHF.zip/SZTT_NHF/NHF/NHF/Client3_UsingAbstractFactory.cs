﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    class Client3_UsingAbstractFactory

    {

        // UI elemek

        private Window wnd;

        private Button button;

        // ...

        // Factory interfész, ezt használja majd a kliens a GUI elemek 

        // létrehozásához.

        private GUIFactory factory;



        public void SetFactory(GUIFactory fy)

        {

            factory = fy;

        }



        public void InitGUIElements()

        {

            wnd = factory.CreateWindow();

            button = factory.CreateButton();

            //...

        }



        public void DoSomethingComplex()

        {

            // Demonstráljuk a GUI elemek kirajzolását:

            wnd.Show();

            wnd.Paint();

            button.Paint();

            //...

        }

    }





    // Demonstrálja a ClientUsingFactory osztály használatát.

    // A futtatáshoz nevezzük át a függvényt Main-re

    class DemoClientUsage

    {

        static void Main2(string[] args)

        {

            Client3_UsingAbstractFactory client = new Client3_UsingAbstractFactory();

            GUIFactory factory;



            // Konfiguráljuk fel a klienst egy adott factory objektummal. A kliens

            // ezt fogja használni az GUI objektumainak létrehozásához.

            // Ha Win10 megjelenítést szeretnék:

            factory = new OSXGUIFactory();

            // Ha Presentation Manager megjelenítést szeretnék, akkor csak az előző

            // sort kell megváltoztatni, a ClientUsingFactory osztályhoz nem kell

            // hozzányúlni, az független a témától!

            client.SetFactory(factory);

            client.InitGUIElements();



            // ...

            client.DoSomethingComplex();

            // ...



        }

    }



}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    public class Client2_UsingInterfaces

    {

        // GUI elemek, most már interfészként hivatkozzuk őket

        private Window wnd;

        private Button button;

        // ...



        public void InitGUIElements()

        {

            // GUI elemek létrehozása, itt, ha a new operátort használjuk,

            // akkor muszál konkrét témához tartozó osztályt megadni.

            // Ha témát akarunk váltani, át kell írni a sorokat a kódban.

            wnd = new Win10Window();

            button = new Win10Button();

            //...

        }

        public void DoSomethingComplex()

        {

            // Demonstráljuk a GUI elemek kirajzolását:

            wnd.Show();

            wnd.Paint();

            button.Paint();

        }

    }

}

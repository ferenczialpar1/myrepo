﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    public class Alarmsystem
    {
        private static Alarmsystem instance = null;
        public static Alarmsystem GetInstance()
        {
            if (instance == null)
                instance = new Alarmsystem();
            return instance;
        }
        protected Alarmsystem() { }
        public bool Diagnostics(Frame carframe, Body carbody, Engine carengine) 
        {
            if (carframe.GetType().Name[5].ToString().Equals(carengine.GetType().Name[5].ToString()) && carframe.GetType().Name[5].ToString().Equals(carbody.GetType().Name[5].ToString()))
            {
                return true;
            }
            else
            {
                Console.WriteLine("Check problem!");
                return false;
            }
        }
        public static void FrameDiagnostics()
        {
            try
            {
                //qualityCheck(carframe);
                Console.WriteLine("OK");
            }
            catch (Exception e)
            {
                string ErrorString = e.Message;
                Console.WriteLine(ErrorString);
            }
        }
        public bool qualityCheck(Frame carframe)
        {
            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    public class RoadsterFrame : Frame
    {
        public override void AssemblyFrame()
        {
            Alarmsystem.FrameDiagnostics();
            Console.WriteLine(this.GetType().Name + " complete");
        }
    }

    public class RoadsterBody : Body

    {
        public override void AssemblyBody()
        {
            Alarmsystem.FrameDiagnostics();
            Console.WriteLine(this.GetType().Name + " complete");
        }
    }

    public class RoadsterEngine : Engine
    {
        public override void AssemblyEngine()
        {
            Alarmsystem.FrameDiagnostics();
            Console.WriteLine(this.GetType().Name + " complete");
        }
    }
}

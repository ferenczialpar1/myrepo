﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    public class ModelYFrame : Frame
    {
        public override void AssemblyFrame()
        {
            Alarmsystem.FrameDiagnostics();
            Console.WriteLine(this.GetType().Name + " complete");
        }
    }

    public class ModelYBody : Body

    {
        public override void AssemblyBody()
        {
            Alarmsystem.FrameDiagnostics();
            Console.WriteLine(this.GetType().Name + " complete");
        }
    }

    public class ModelYEngine : Engine

    {
        public override void AssemblyEngine()
        {
            Alarmsystem.FrameDiagnostics();
            Console.WriteLine(this.GetType().Name + " complete");
        }
    }
}

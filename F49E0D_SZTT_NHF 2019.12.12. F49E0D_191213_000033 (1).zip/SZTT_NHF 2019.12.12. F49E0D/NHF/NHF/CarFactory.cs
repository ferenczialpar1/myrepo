﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace NHF
{
    interface CarFactory
    {
        public static Collection<Car> MyList= new Collection<Car>();

        Frame CreateFrame();
        Body CreateBody();
        Engine CreateEngine();
        public void makeCars(int n)
        {
            for(int i=0; i<n; i++)
            {
                if (i==4)
                {
                    ModelSEngine modelsengine = new ModelSEngine();
                    assembleCars(CreateFrame(), CreateBody(), modelsengine);
                }
                else
                {
                    assembleCars(CreateFrame(), CreateBody(), CreateEngine());
                }
                Console.WriteLine(this.GetType().Name + "Made a new car");
            }
        }
        public void assembleCars(Frame carframe, Body carbody, Engine carengine)
        {
            if(Alarmsystem.GetInstance().Diagnostics(carframe, carbody, carengine))
            {
                Car newcar = new Car(carframe, carbody, carengine);
                MyList.Add(newcar);
            }
        }
        public void printOrderList()
        {
            Console.WriteLine("WAREHOUSE Inventory: " + MyList.Count + " new car in stock");

        }
    }
    class TeslaModelSFactory : CarFactory
    {
        public Frame CreateFrame() { return new ModelSFrame(); }
        public Body CreateBody() { return new ModelSBody(); }
        public Engine CreateEngine() { return new ModelSEngine(); }

        }
    class TeslaModelYFactory : CarFactory
    {
        public Frame CreateFrame() { return new ModelYFrame(); }
        public Body CreateBody() { return new ModelYBody(); }
        public Engine CreateEngine() { return new ModelYEngine(); }

    }
    class TeslaModelRoadsterFactory : CarFactory
    {
        public Frame CreateFrame() { return new RoadsterFrame(); }
        public Body CreateBody() { return new RoadsterBody(); }
        public Engine CreateEngine() { return new RoadsterEngine(); }

    }
    public class CarCollection
    {
        List<Car> warehouse = new List<Car>();
        public void AddWarehouse(Car newcar)
        {
            warehouse.Add(newcar);
        }
    }
}


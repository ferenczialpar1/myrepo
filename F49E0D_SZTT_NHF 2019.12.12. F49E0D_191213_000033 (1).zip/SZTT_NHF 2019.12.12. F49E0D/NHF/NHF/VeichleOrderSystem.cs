﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHF
{
    class VeichleOrderSystem
    {
        private Frame frame;
        private Body body;
        private Engine engine;

        private CarFactory factory;

        public void SetFactory(CarFactory fy)
        {
            factory = fy;
        }

        public void InitElements()
        {
            frame = factory.CreateFrame();
            body = factory.CreateBody();
            engine = factory.CreateEngine();
        }
        public void DoSomethingComplex()
        {
            frame.AssemblyFrame();
            body.AssemblyBody();
            engine.AssemblyEngine();
        }
    }
    class DemoOrderSystem
    {
        static void Main(string[] args)
        {
            VeichleOrderSystem client = new VeichleOrderSystem();
            CarFactory factory;

            factory = new TeslaModelSFactory();
            factory.makeCars(10);
            factory = new TeslaModelRoadsterFactory();
            client.SetFactory(factory);
            factory.makeCars(5);
            factory.printOrderList();
        }
    }
}
